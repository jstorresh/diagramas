import { useEffect, useState } from 'react'

const colors = [
  { name: 'Noche', token: '--color-night', hex: '#14072E', role: 'Fondo base del video', text: 'ink' },
  { name: 'Crepúsculo', token: '--color-dusk', hex: '#241048', role: 'Paneles y superficies', text: 'ink' },
  { name: 'Violeta', token: '--color-violet', hex: '#3B1C7A', role: 'Horizonte, degradados', text: 'ink' },
  { name: 'Rosa neón', token: '--color-pink', hex: '#FF4FD8', role: 'Acento principal, CTA', text: 'night' },
  { name: 'Cian', token: '--color-cyan', hex: '#38F2FF', role: 'Acento secundario, rejilla', text: 'night' },
  { name: 'Sol', token: '--color-sun', hex: '#FF9A4D', role: 'Herencia del naranja actual: Fuego Nuevo', text: 'night' },
  { name: 'Lila', token: '--color-lilac', hex: '#C9A9FF', role: 'Líneas, texto secundario', text: 'night' },
  { name: 'Menta', token: '--color-mint', hex: '#7DFFD4', role: 'Datos, números (260, 52)', text: 'night' },
]

const backgrounds = [
  { name: 'Cielo', token: '--grad-sky', css: 'linear-gradient(180deg,#14072e,#3b1c7a 55%,#b0449f)', use: 'Portada y cierre' },
  { name: 'Atardecer', token: '--grad-sunset', css: 'linear-gradient(180deg,#ff9a4d,#ff4fd8 55%,#7a3cff)', use: 'Sol, Fuego Nuevo' },
  { name: 'Neón', token: '--grad-neon', css: 'linear-gradient(90deg,#38f2ff,#ff4fd8)', use: 'Barras, líneas, bordes' },
]

function Dial({ variant = 'rings', size = 220 }: { variant?: 'rings' | 'beads' | 'sun'; size?: number }) {
  const ticks = Array.from({ length: 20 }, (_, i) => i)
  return (
    <svg viewBox="-110 -110 220 220" width={size} height={size} role="img" aria-label="Rueda del calendario">
      <defs>
        <linearGradient id={`g-${variant}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#38f2ff" />
          <stop offset="1" stopColor="#ff4fd8" />
        </linearGradient>
      </defs>
      <circle r="100" fill="none" stroke="#c9a9ff" strokeOpacity=".5" />
      <circle r="84" fill="none" stroke={`url(#g-${variant})`} strokeWidth="2" style={{ filter: 'drop-shadow(0 0 5px #ff4fd8)' }} />
      <circle r="58" fill="none" stroke="#ff9a4d" strokeOpacity=".8" />
      {variant === 'rings' &&
        ticks.map((i) => (
          <line key={i} x1="0" y1="-94" x2="0" y2="-88" stroke="#fff3ff" strokeWidth="2" transform={`rotate(${i * 18})`} />
        ))}
      {variant === 'beads' && (
        <>
          {ticks.map((i) => (
            <circle key={i} cx="0" cy="-92" r="5" fill="#14072e" stroke={i % 2 ? '#38f2ff' : '#ff4fd8'} strokeWidth="1.5" transform={`rotate(${i * 18})`} />
          ))}
          <text textAnchor="middle" y="14" fontSize="42" fontWeight="800" fontFamily="Unbounded" fill="#7dffd4" style={{ filter: 'drop-shadow(0 0 6px #7dffd4)' }}>
            260
          </text>
        </>
      )}
      {variant === 'sun' && (
        <>
          <circle r="30" fill="#ff9a4d" style={{ filter: 'drop-shadow(0 0 14px #ff4fd8)' }} />
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <line key={i} x1="-34" x2="34" y1={-6 + i * 4} y2={-6 + i * 4} stroke="#241048" strokeWidth={i * 0.5} transform="translate(0,6)" />
          ))}
        </>
      )}
      {variant === 'rings' && <circle r="6" fill="#ff9a4d" style={{ filter: 'drop-shadow(0 0 8px #ff9a4d)' }} />}
    </svg>
  )
}

function SectionHead({ n, title, kana, intro }: { n: string; title: string; kana: string; intro: string }) {
  return (
    <header className="mb-10 max-w-2xl">
      <p className="font-mono text-xs tracking-[0.3em] text-cyan uppercase">
        {n} <span className="font-kana text-lilac ml-2 tracking-normal">{kana}</span>
      </p>
      <h2 className="font-display font-extrabold text-3xl md:text-5xl mt-3 text-chrome leading-tight">{title}</h2>
      <p className="mt-4 text-lilac text-lg leading-relaxed">{intro}</p>
    </header>
  )
}

function Swatch({ c }: { c: (typeof colors)[number] }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      onClick={() => {
        navigator.clipboard?.writeText(c.hex)
        setCopied(true)
        setTimeout(() => setCopied(false), 1200)
      }}
      className="group text-left rounded-sm overflow-hidden border border-lilac/30 bg-dusk/70 transition hover:-translate-y-1 hover:border-pink focus-visible:outline-2 focus-visible:outline-cyan"
    >
      <div className="h-24 relative" style={{ background: c.hex, boxShadow: `inset 0 -30px 40px -20px rgba(0,0,0,.35)` }}>
        <span className={`absolute right-2 top-2 font-mono text-[10px] px-1.5 py-0.5 ${copied ? 'bg-mint text-night' : 'bg-night/60 text-ink opacity-0 group-hover:opacity-100'} transition`}>
          {copied ? 'copiado' : 'copiar'}
        </span>
      </div>
      <div className="p-3">
        <p className="font-display text-sm font-semibold">{c.name}</p>
        <p className="font-mono text-xs text-cyan mt-1">{c.hex}</p>
        <p className="font-mono text-[10px] text-lilac/80 mt-1">{c.token}</p>
        <p className="text-xs text-lilac mt-2 leading-snug">{c.role}</p>
      </div>
    </button>
  )
}

const subtitleLines = [
  'Para la civilización azteca, el tiempo no era un hilo sin retorno:',
  'era una danza cósmica donde el destino divino',
  'y la tierra se entrelazaban.',
]

function SubtitlePanel({ mode }: { mode: 'clasico' | 'karaoke' | 'cristal' }) {
  const [i, setI] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % subtitleLines.length), 2200)
    return () => clearInterval(t)
  }, [])
  const words = subtitleLines[i].split(' ')
  const [w, setW] = useState(0)
  useEffect(() => {
    setW(0)
    const t = setInterval(() => setW((v) => v + 1), 2000 / words.length)
    return () => clearInterval(t)
  }, [i, words.length])

  const shell =
    mode === 'clasico'
      ? 'border-t-2 border-pink bg-night/80 px-5 py-4'
      : mode === 'karaoke'
        ? 'bg-black/55 px-5 py-4 border-l-4 border-cyan'
        : 'backdrop-blur-md bg-white/10 border border-white/30 rounded-xl px-5 py-4 shadow-[0_0_30px_rgba(255,79,216,.25)]'
  return (
    <div className={`${shell} min-h-[96px] transition`}>
      {mode !== 'cristal' && (
        <p className="font-mono text-[10px] tracking-[0.25em] text-sun uppercase mb-2">
          {mode === 'clasico' ? '20 signos × 13 numerales' : 'Narración · 00:0' + (i + 3)}
        </p>
      )}
      <p className="text-lg leading-snug font-medium">
        {mode === 'karaoke'
          ? words.map((x, k) => (
              <span key={k} className={`transition-colors ${k < w ? 'text-cyan' : 'text-ink/70'}`} style={k < w ? { textShadow: '0 0 12px #38f2ff' } : undefined}>
                {x}{' '}
              </span>
            ))
          : subtitleLines[i]}
      </p>
    </div>
  )
}

function PlayerBar() {
  const [playing, setPlaying] = useState(true)
  const [t, setT] = useState(3)
  const total = 68
  useEffect(() => {
    if (!playing) return
    const id = setInterval(() => setT((v) => (v >= total ? 0 : v + 1)), 1000)
    return () => clearInterval(id)
  }, [playing])
  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
  return (
    <div className="bg-night/90 border border-lilac/30 px-4 py-3">
      <input
        type="range"
        min={0}
        max={total}
        value={t}
        onChange={(e) => setT(+e.target.value)}
        aria-label="Progreso"
        className="w-full h-1 accent-pink cursor-pointer"
      />
      <div className="flex items-center gap-4 mt-3 font-mono text-xs">
        <button onClick={() => setPlaying(!playing)} aria-label={playing ? 'Pausar' : 'Reproducir'} className="size-9 grid place-items-center bg-pink text-night hover:bg-cyan transition shadow-[0_0_16px_rgba(255,79,216,.7)]">
          {playing ? '❚❚' : '▶'}
        </button>
        <span className="text-cyan">{fmt(t)} / {fmt(total)}</span>
        <span className="ml-auto text-lilac font-kana text-sm">ボリューム ▮▮▮▯</span>
        <span className="text-lilac">⛶</span>
      </div>
    </div>
  )
}

function Frame({ kicker, title, children, caption, page, big }: { kicker: string; title: string; children: React.ReactNode; caption: string; page: string; big?: boolean }) {
  return (
    <div className="relative aspect-[9/16] w-full overflow-hidden border border-lilac/40 scanlines" style={{ background: 'var(--grad-sky)' }}>
      <div className="absolute bottom-0 inset-x-0 h-[34%] overflow-hidden" aria-hidden>
        <div className="grid-floor absolute inset-x-[-40%] top-0 h-[220%]" style={{ animation: 'drift 3s linear infinite' }} />
      </div>
      <div className="absolute left-1/2 -translate-x-1/2 bottom-[30%] size-28 rounded-full opacity-90" style={{ background: 'var(--grad-sunset)', clipPath: 'inset(0 0 0 0)' }} aria-hidden />
      <div className="relative z-10 h-full flex flex-col p-5">
        <div className="flex justify-between font-mono text-[9px] tracking-[0.2em] text-lilac uppercase">
          <span>Archivo del tiempo</span>
          <span>{page}</span>
        </div>
        <p className="mt-6 font-mono text-[10px] tracking-[0.25em] text-sun uppercase">{kicker}</p>
        <h3 className={`font-display font-extrabold leading-[1.05] mt-2 text-chrome ${big ? 'text-2xl' : 'text-xl'}`}>{title}</h3>
        <div className="flex-1 grid place-items-center">{children}</div>
        <div className="bg-night/80 border-t-2 border-pink p-3 mb-6 backdrop-blur-sm">
          <p className="text-[12px] leading-snug">{caption}</p>
        </div>
        <p className="absolute bottom-2 inset-x-0 text-center font-kana text-[9px] text-lilac/70">ドス・クエンタス · メソアメリカ</p>
      </div>
    </div>
  )
}

export default function App() {
  const [mode, setMode] = useState<'clasico' | 'karaoke' | 'cristal'>('clasico')
  const [variant, setVariant] = useState<'primary' | 'secondary' | 'ghost'>('primary')

  return (
    <main className="min-h-screen overflow-x-hidden">
      {/* HERO */}
      <section className="relative min-h-[88vh] flex items-end overflow-hidden" style={{ background: 'var(--grad-sky)' }}>
        <div className="absolute bottom-0 inset-x-0 h-[45%] overflow-hidden" aria-hidden>
          <div className="grid-floor absolute inset-x-[-40%] top-0 h-[250%]" style={{ animation: 'drift 3s linear infinite' }} />
        </div>
        <div className="absolute left-1/2 -translate-x-1/2 bottom-[36%] size-[min(46vw,340px)] rounded-full" style={{ background: 'var(--grad-sunset)', maskImage: 'repeating-linear-gradient(180deg,#000 0 14px,transparent 14px 17px)', boxShadow: '0 0 90px rgba(255,79,216,.55)' }} aria-hidden />
        <div className="relative z-10 w-full max-w-6xl mx-auto px-6 pb-16 pt-28">
          <p className="font-mono text-xs tracking-[0.35em] text-cyan uppercase">
            Sistema de diseño · v2 <span className="font-kana text-lilac ml-3 tracking-normal">アステカ暦</span>
          </p>
          <h1 className="font-display font-extrabold text-4xl md:text-7xl leading-[1.02] mt-5 text-chrome chroma-none max-w-4xl">
            El arte del tiempo azteca, en vaporwave
          </h1>
          <p className="mt-6 max-w-xl text-lg text-ink/90">
            Variables, tipografía y componentes para la siguiente versión del video. Se mantiene la estructura vertical actual (título, anillo, panel de texto, reproductor) con un lenguaje neón.
          </p>
          <nav className="mt-8 flex flex-wrap gap-3 font-mono text-xs uppercase tracking-widest">
            {[['#color', '01 Color'], ['#fondos', '02 Fondos'], ['#tipografia', '03 Tipografía'], ['#componentes', '04 Componentes'], ['#pantallas', '05 Pantallas']].map(([h, l]) => (
              <a key={h} href={h} className="px-3 py-2 border border-lilac/50 hover:bg-pink hover:text-night hover:border-pink transition">{l}</a>
            ))}
          </nav>
        </div>
      </section>

      {/* COLOR */}
      <section id="color" className="max-w-6xl mx-auto px-6 py-24">
        <SectionHead n="01" kana="色" title="Variables de color" intro="Un fondo noche profundo conserva el contraste del video actual; el naranja del original sobrevive como “Sol” y se acompaña de rosa y cian neón. Toca una muestra para copiar el hex." />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {colors.map((c) => <Swatch key={c.token} c={c} />)}
        </div>
        <div className="mt-8 grid md:grid-cols-3 gap-4 font-mono text-xs text-lilac">
          <p className="border border-lilac/30 p-4">Texto principal: <span className="text-ink">#FFF3FF</span> sobre Noche = 17:1</p>
          <p className="border border-lilac/30 p-4">Subtítulos: máx. 2 colores de acento por pantalla (rosa + cian, o sol + menta).</p>
          <p className="border border-lilac/30 p-4">Brillo (glow): 18px, 60% opacidad. Solo en acentos, nunca en párrafos.</p>
        </div>
      </section>

      {/* FONDOS */}
      <section id="fondos" className="bg-dusk/50 border-y border-lilac/20">
        <div className="max-w-6xl mx-auto px-6 py-24">
          <SectionHead n="02" kana="背景" title="Fondos y texturas" intro="Cada escena es un paisaje: cielo en degradado, sol segmentado como horizonte y rejilla cian en perspectiva. Líneas de escaneo suaves reemplazan la textura de rejilla oscura actual." />
          <div className="grid md:grid-cols-3 gap-4">
            {backgrounds.map((b) => (
              <div key={b.token} className="border border-lilac/30">
                <div className="h-44" style={{ background: b.css }} />
                <div className="p-4 bg-night/70">
                  <p className="font-display text-sm font-semibold">{b.name}</p>
                  <p className="font-mono text-xs text-cyan mt-1">{b.token}</p>
                  <p className="text-sm text-lilac mt-2">{b.use}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 grid md:grid-cols-2 gap-4">
            <div className="relative h-48 overflow-hidden border border-lilac/30 bg-night">
              <div className="grid-floor absolute inset-x-[-40%] top-0 h-[300%]" style={{ animation: 'drift 3s linear infinite' }} />
              <p className="absolute left-4 bottom-3 font-mono text-xs bg-night/80 px-2 py-1">.grid-floor · rejilla 48px, inclinación 62°</p>
            </div>
            <div className="relative h-48 overflow-hidden border border-lilac/30 scanlines" style={{ background: 'var(--grad-sky)' }}>
              <p className="absolute left-4 bottom-3 font-mono text-xs bg-night/80 px-2 py-1">.scanlines · líneas 3px, 14% negro</p>
            </div>
          </div>
        </div>
      </section>

      {/* TIPOGRAFIA */}
      <section id="tipografia" className="max-w-6xl mx-auto px-6 py-24">
        <SectionHead n="03" kana="文字" title="Estilo tipográfico" intro="El serif pesado actual se reemplaza por una display ancha y geométrica con acabado cromado. El cuerpo es cálido y legible a tamaño de subtítulo; el mono da el tono de interfaz retro." />
        <div className="grid md:grid-cols-[1.2fr_1fr] gap-6">
          <div className="border border-lilac/30 p-6 bg-dusk/60">
            <p className="font-mono text-xs text-cyan">TÍTULO · Unbounded ExtraBold · 32–44px · interlineado 1.05</p>
            <p className="font-display font-extrabold text-4xl md:text-5xl text-chrome mt-4 leading-[1.05]">EL ARTE DEL TIEMPO AZTECA</p>
            <hr className="border-lilac/20 my-6" />
            <p className="font-mono text-xs text-cyan">SUBTÍTULO ESCENA · Unbounded SemiBold · 22–26px</p>
            <p className="font-display font-semibold text-2xl mt-3">Tonalpohualli</p>
            <hr className="border-lilac/20 my-6" />
            <p className="font-mono text-xs text-cyan">DATO · Unbounded ExtraBold · 72–96px · menta + glow</p>
            <p className="font-display font-extrabold text-7xl mt-3 text-mint" style={{ textShadow: '0 0 22px rgba(125,255,212,.6)' }}>260</p>
          </div>
          <div className="space-y-6">
            <div className="border border-lilac/30 p-6 bg-dusk/60">
              <p className="font-mono text-xs text-cyan">CUERPO / SUBTÍTULOS · Outfit Medium · 18–22px</p>
              <p className="mt-3 text-xl leading-snug font-medium">Su combinación marcaba los ritos y el destino de cada día. El ciclo se completaba cada 260 días.</p>
            </div>
            <div className="border border-lilac/30 p-6 bg-dusk/60">
              <p className="font-mono text-xs text-cyan">ETIQUETA · DM Mono Medium · 10–12px · +25% tracking · MAYÚSCULAS</p>
              <p className="mt-3 font-mono text-sm tracking-[0.25em] uppercase text-sun">El ciclo ritual</p>
            </div>
            <div className="border border-lilac/30 p-6 bg-dusk/60">
              <p className="font-mono text-xs text-cyan">DETALLE KANA · DotGothic16 · solo decorativo</p>
              <p className="mt-3 font-kana text-2xl text-lilac">アステカ暦 · 太陽の石</p>
            </div>
          </div>
        </div>
      </section>

      {/* COMPONENTES */}
      <section id="componentes" className="bg-dusk/50 border-y border-lilac/20">
        <div className="max-w-6xl mx-auto px-6 py-24">
          <SectionHead n="04" kana="部品" title="Componentes" intro="Botones, etiquetas, panel de subtítulos y reproductor. Todos con bordes rectos (sin redondeo, salvo el panel de cristal) y brillo en estado activo." />

          <div className="grid md:grid-cols-2 gap-6">
            {/* Botones */}
            <div className="border border-lilac/30 p-6 bg-night/60">
              <h3 className="font-display text-sm font-semibold mb-5">Botones</h3>
              <div className="flex flex-wrap gap-3 mb-6" role="tablist">
                {(['primary', 'secondary', 'ghost'] as const).map((v) => (
                  <button key={v} onClick={() => setVariant(v)} aria-pressed={variant === v} className={`font-mono text-[11px] uppercase tracking-widest px-3 py-1.5 border transition ${variant === v ? 'bg-cyan text-night border-cyan' : 'border-lilac/40 text-lilac hover:border-cyan'}`}>
                    {v === 'primary' ? 'Primario' : v === 'secondary' ? 'Secundario' : 'Fantasma'}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-4">
                <button className={`font-display font-semibold text-sm px-6 py-3 transition active:translate-y-px focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan ${variant === 'primary' ? 'bg-pink text-night shadow-[0_0_20px_rgba(255,79,216,.65)] hover:bg-cyan hover:shadow-[0_0_20px_rgba(56,242,255,.65)]' : variant === 'secondary' ? 'border-2 border-cyan text-cyan hover:bg-cyan hover:text-night' : 'text-ink underline underline-offset-8 decoration-pink hover:text-pink'}`}>
                  ▶ Ver video
                </button>
                <button disabled className="font-display font-semibold text-sm px-6 py-3 bg-violet/60 text-lilac/50 cursor-not-allowed">Deshabilitado</button>
              </div>
              <ul className="mt-6 font-mono text-[11px] text-lilac space-y-1">
                <li>· Alto 44px mínimo, esquinas rectas</li>
                <li>· Hover: rosa → cian · Foco: contorno cian 2px</li>
              </ul>
            </div>

            {/* Etiquetas */}
            <div className="border border-lilac/30 p-6 bg-night/60">
              <h3 className="font-display text-sm font-semibold mb-5">Etiquetas y chips</h3>
              <div className="flex flex-wrap gap-3 mb-6">
                <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-sun">Calendario mexica</span>
                <span className="font-mono text-[11px] tracking-widest uppercase px-2 py-1 border border-cyan text-cyan">Ritual</span>
                <span className="font-mono text-[11px] tracking-widest uppercase px-2 py-1 bg-pink/20 border border-pink text-pink">Sol</span>
                <span className="font-mono text-[11px] tracking-widest uppercase px-2 py-1 border border-mint text-mint -rotate-3">Renovación</span>
              </div>
              <h3 className="font-display text-sm font-semibold mb-3">Indicador de capítulo</h3>
              <div className="flex items-center gap-3 font-mono text-xs">
                <span className="text-lilac">ARCHIVO DEL TIEMPO</span>
                <span className="flex-1 h-px bg-lilac/40" />
                <span className="text-cyan">02 — 04</span>
              </div>
              <div className="mt-4 flex gap-2" aria-label="Progreso de capítulos">
                {[0, 1, 2, 3].map((i) => <span key={i} className="h-1 flex-1" style={{ background: i <= 1 ? 'var(--grad-neon)' : 'rgba(201,169,255,.25)' }} />)}
              </div>
              <h3 className="font-display text-sm font-semibold mt-8 mb-3">Titular con dato</h3>
              <p className="font-display font-extrabold text-xl tracking-wide text-sun" style={{ textShadow: '0 0 14px rgba(255,154,77,.6)' }}>CADA 52 AÑOS</p>
            </div>
          </div>

          {/* Subtitulos */}
          <div className="mt-6 grid lg:grid-cols-[1fr_1.2fr] gap-6">
            <div className="border border-lilac/30 p-6 bg-night/60">
              <h3 className="font-display text-sm font-semibold mb-2">Panel de subtítulos</h3>
              <p className="text-sm text-lilac mb-5">Tres variantes. Máximo 2 líneas, 42 caracteres por línea, anclado al tercio inferior.</p>
              <div className="flex flex-wrap gap-2 mb-5">
                {([['clasico', 'Clásico'], ['karaoke', 'Karaoke'], ['cristal', 'Cristal']] as const).map(([k, l]) => (
                  <button key={k} onClick={() => setMode(k)} aria-pressed={mode === k} className={`font-mono text-[11px] uppercase tracking-widest px-3 py-1.5 border transition ${mode === k ? 'bg-pink text-night border-pink' : 'border-lilac/40 text-lilac hover:border-pink'}`}>{l}</button>
                ))}
              </div>
              <ul className="font-mono text-[11px] text-lilac space-y-1">
                <li>· Clásico: línea rosa superior, equivale a la regla actual</li>
                <li>· Karaoke: palabras se iluminan en cian al narrarse</li>
                <li>· Cristal: vidrio esmerilado para escenas con mucho detalle</li>
              </ul>
            </div>
            <div className="relative p-6 border border-lilac/30 scanlines overflow-hidden" style={{ background: 'var(--grad-sky)' }}>
              <div className="h-40 grid place-items-center"><Dial variant="rings" size={150} /></div>
              <SubtitlePanel mode={mode} />
            </div>
          </div>

          {/* Player */}
          <div className="mt-6 border border-lilac/30 p-6 bg-night/60">
            <h3 className="font-display text-sm font-semibold mb-2">Reproductor</h3>
            <p className="text-sm text-lilac mb-5">Botón de reproducción cuadrado en rosa, tiempo en cian y barra con acento rosa. Funcional: pausa y arrastra.</p>
            <PlayerBar />
          </div>
        </div>
      </section>

      {/* PANTALLAS */}
      <section id="pantallas" className="max-w-6xl mx-auto px-6 py-24">
        <SectionHead n="05" kana="画面" title="Las tres pantallas, rediseñadas" intro="Misma jerarquía que el video actual (etiqueta, título, anillo, panel de texto, pie) aplicada al nuevo sistema." />
        <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <Frame kicker="Calendario mexica" title="EL ARTE DEL TIEMPO AZTECA" page="01 — 04" big caption="Para la civilización azteca, el tiempo no era un hilo sin retorno: era una danza cósmica.">
            <Dial variant="rings" size={190} />
          </Frame>
          <Frame kicker="El ciclo ritual" title="Tonalpohualli" page="02 — 04" caption="20 signos × 13 numerales. El ciclo se completaba cada 260 días.">
            <Dial variant="beads" size={190} />
          </Frame>
          <Frame kicker="La gran renovación" title="Fuego Nuevo" page="04 — 04" caption="Cada 52 años, ambos ciclos volvían a coincidir. Una nueva rueda para la vida.">
            <Dial variant="sun" size={190} />
          </Frame>
        </div>
      </section>

      <footer className="border-t border-lilac/20 py-10 text-center font-mono text-xs text-lilac tracking-widest">
        <span className="font-kana">時間の芸術</span> · DOS CUENTAS · MESOAMÉRICA
        <span className="inline-block w-2 h-4 bg-pink ml-2 align-middle" style={{ animation: 'blink 1s steps(1) infinite' }} />
      </footer>
    </main>
  )
}
